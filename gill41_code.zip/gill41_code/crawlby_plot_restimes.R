source("crawlby_funs.R")

#####################
## RESIDENCE TIMES ##
#####################

load("trajset.RData")

## HISTOGRAMS

if (!interactive()) png("trajectories.png", width=1020, height=1020)
## phase portraits
tmax <- 1000
library(dplyr)
mfrow.orig <- par(mfrow=c(2,2))
cex.orig <- par(cex=1.5)
oma.orig <- par(oma = c(0, 0, 3, 0)) # allow overall title
for (i in 1:length(trajset)) {
    traj <- trajset[[i]]$traj %>% filter(t<=tmax)
    pp_plot(traj, skip=1)
    r.sigma <- trajset[[i]]$model$r.sigma
    h.sigma <- trajset[[i]]$model$h.sigma
    legend("topright",bty="n",
           legend=latex2exp::TeX(sprintf("$\\sigma_r = %g,\\,\\sigma_h = %g$", r.sigma, h.sigma)))
}
## overall title:
stopTime <- attr(traj,"model")$stopTime
K <- attr(traj,"model")$K
mtext(sprintf("Trajectories up to time %.1f (of %.1f)\nK = %g",tmax, stopTime, K), outer=TRUE, cex=2)
par(mfrow=mfrow.orig)
par(cex=cex.orig)
par(oma=oma.orig)
if (!interactive()) dev.off()

if (!interactive()) pdf("diagnostic_histograms.pdf")
## event time steps
mfrow.orig <- par(mfrow=c(2,2))
for (i in 1:length(trajset)) {
    tau_hist(trajset[[i]]$traj, quantile.max=0.99)
}
par(mfrow=mfrow.orig)

## r histograms
mfrow.orig <- par(mfrow=c(2,2))
for (i in 1:length(trajset)) {# start at 2 because 1 has no noise
    r_hist(trajset[[i]]$traj)
}
for (i in 1:length(trajset)) {
    h_hist(trajset[[i]]$traj)
}
par(mfrow=mfrow.orig)

## histgrams of cell residence times
## mfrow.orig <- par(mfrow = c(2,1))
## for (i in 1:length(restimeset)) {
##     hist_cell_times( restimeset[[i]]$cell.times )
## }
## par(mfrow=mfrow.orig)

if (!interactive()) dev.off()

##############################################################
## for Jon: near-origin residence times calculated like him ##
##############################################################

hist_region_times <- function( x, region, model ) {
    xlength <- length(x)
    xmean <- mean(x)
    xsd <- sd(x)
    xmin <- floor(max(0, xmean-3*xsd))
    xmax <- ceiling(xmean + 3*xsd)
    message(region, ": xmin = ", xmin, ", xmax = ", xmax)
    xlim <- c(xmin,xmax) # this is best to see the structure of the histogram
    ## this is best to compare histograms:
    xlim <- switch(region
                   , ORIGIN = c(0,14)
                   , CC = c(0,30)
                   , yNULLCLINE = c(1,5)
                   , c(0,60)
                   )
    r.sigma <- model$r.sigma
    h.sigma <- model$h.sigma
    algorithm <- model$algorithm
    out <- hist(x
       , las=1
       , xlim=xlim
       , xlab="Residence time"
       , main=if (region=="CYCLE") "Full Cycle Times" else sprintf("Residence times near %s", region)
         )
    legend("topright", bty="n"
         , legend=c(sprintf("ncycles = %d", length(x))
                  , sprintf("mean = %.2f", mean(x))
                  , sprintf("sd = %.3g", sd(x))
                    )
           )
    legend("bottomright", bty="n", legend=algorithm)
    legend("topleft",bty="n",
           legend=latex2exp::TeX(sprintf(
                                 "$\\sigma_r = %g,\\,\\sigma_h = %g$", r.sigma, h.sigma))
           )
    return(invisible(out))
}

load("restimeset.RData")

if (!interactive()) pdf("restimes.pdf", height=6, width=12)
mfrow.orig <- par(mfrow=c(2,4))
origin.times <- list()
oeet <- list()
cc.times <- list()
cceet <- list()
yn.times <- list()
yneet <- list()
cycle.times <- list()
for (i in 1:length(restimeset)) {
    origin.times[[i]] <- restimeset[[i]]$rtl$origin.times
    oeet[[i]] <- restimeset[[i]]$rtl$origin.entry.exit.times # for debugging
    cc.times[[i]] <- restimeset[[i]]$rtl$cc.times
    cceet[[i]] <- restimeset[[i]]$rtl$cc.entry.exit.times # for debugging
    yn.times[[i]] <- restimeset[[i]]$rtl$yn.times
    yneet[[i]] <- restimeset[[i]]$rtl$yn.entry.exit.times # for debugging
    cycle.times[[i]] <- restimeset[[i]]$rtl$cycle.times
    hist_region_times(origin.times[[i]], "ORIGIN", restimeset[[i]]$model)
    hist_region_times(cc.times[[i]], "CC", restimeset[[i]]$model)
    hist_region_times(yn.times[[i]], "yNULLCLINE", restimeset[[i]]$model)
    hist_region_times(cycle.times[[i]], "CYCLE", restimeset[[i]]$model)
}
par(mfrow=mfrow.orig)
if (!interactive()) dev.off()
