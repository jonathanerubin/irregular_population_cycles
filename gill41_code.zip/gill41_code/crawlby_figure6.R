
source("crawlby_funs.R")

if (!interactive()) pdf("figure6.pdf",  width=8.5, height=8.5)

cols <- c(origin="red", region2="grey", cc="blue",
          region4="grey", yn="darkgreen", region6="grey")

## LAYOUT FOR CENTRAL PHASE PORTRAIT AND SURROUNDING HISTOGRAMS

oma.orig <- par(oma = c(0, 0, 3, 0)) # allow overall title
cex.orig <- par(cex=0.5)

mat <- matrix(c(9, 5, 7,
                6, 8, 4,
                1, 2, 3),
              3, 3, byrow = TRUE)
layout(mat)
if (interactive()) layout.show(9)

## set simulation number and load restime data
for (i in 1:4) {
##i <- 1
restimefn <- paste0("restimeset", i, ".RData")
load(restimefn)

##############################################################
## for Jon: near-origin residence times calculated like him ##
##############################################################

hist_region_times <- function( x, region, model, col=NULL ) {
    xlength <- length(x)
    xmean <- mean(x)
    xsd <- sd(x)
    xmin <- floor(max(0, xmean-3*xsd))
    xmax <- ceiling(xmean + 3*xsd)
    message(region, ": xmin = ", xmin, ", xmax = ", xmax)
    xlim <- c(xmin,xmax) # this is best to see the structure of the histogram
    ## this is best to compare histograms:
    xlim <- switch(region
                   , ORIGIN = c(0,14)
                   , CC = c(0,30)
                   , yNULLCLINE = c(1,5)
                   , CYCLE = c(0,60)
                   ##, c(1,5)
                   , c(0,8)
                   )
    r.sigma <- model$r.sigma
    h.sigma <- model$h.sigma
    algorithm <- model$algorithm
    out <- hist(x
       , las=1
       , xlim=xlim
       , col=col
       , xlab="Residence time"
       , main=if (region=="CYCLE") "Full Cycle Times" else sprintf("Residence times %s", region)
         )
    legend("topright", bty="n"
         , legend=c(sprintf("ncycles = %d", length(x))
                  , sprintf("mean = %.2f", mean(x))
                  , sprintf("sd = %.3g", sd(x))
                    )
           )
    legend("bottomright", bty="n", legend=algorithm)
    legend("topleft",bty="n",
           legend=latex2exp::TeX(sprintf(
                                 "$\\sigma_r = %g,\\,\\sigma_h = %g$", r.sigma, h.sigma))
           )
    return(invisible(out))
}

model <- restime$model

origin.times <- list()
oeet <- list()
cc.times <- list()
cceet <- list()
yn.times <- list()
yneet <- list()
reg2.times <- list()
reg4.times <- list()
reg6.times <- list()
cycle.times <- list()
####for (i in 1:length(restimeset)) {
origin.times[[i]] <- restime$rtl$origin.times
reg2.times[[i]] <- restime$rtl$reg2.times
##oeet[[i]] <- restime$rtl$origin.entry.exit.times # for debugging
cc.times[[i]] <- restime$rtl$cc.times
reg4.times[[i]] <- restime$rtl$reg4.times
##cceet[[i]] <- restime$rtl$cc.entry.exit.times # for debugging
yn.times[[i]] <- restime$rtl$yn.times
reg6.times[[i]] <- restime$rtl$reg6.times
##yneet[[i]] <- restime$rtl$yn.entry.exit.times # for debugging
cycle.times[[i]] <- restime$rtl$cycle.times
hist_region_times(origin.times[[i]], "ORIGIN", model, col=cols["origin"])
hist_region_times(reg2.times[[i]], "region2", model, col=cols["region2"])
hist_region_times(cc.times[[i]], "CC", model, col=cols["cc"])
hist_region_times(reg4.times[[i]], "region4", model, col=cols["region4"])
hist_region_times(yn.times[[i]], "yNULLCLINE", model, col=cols["yn"])
hist_region_times(reg6.times[[i]], "region6", model, col=cols["region6"])
hist_region_times(cycle.times[[i]], "CYCLE", model)
####}

## save cycle times to a file for Jon
ct <- data.frame(cycle.times = cycle.times[[i]])
ctfn <- sprintf("cycletimes_r%.1f_h%.1f_.csv", model$r.sigma, model$h.sigma)
write.csv(ct, file=ctfn, row.names=FALSE, quote=FALSE)

## add trajectory in the centre of the plot
tmax <- 1000

short.traj.name <- paste0("shorttraj", i, ".RData")
library(dplyr)
if (!file.exists(short.traj.name)) {
    load(paste0("trajset", i, ".RData"))
    traj <- this.trajset$traj %>% filter(t<=tmax)
    save(traj, tmax, file=short.traj.name)
} else {
    load(short.traj.name)
}
##traj <- traj %>% filter(!is.na(clock)) # FIX: too coarse, but quick for now
##tmax <- 100
traj <- traj %>% filter(t <= tmax)

####if (!interactive()) png("trajectories.png", width=1020, height=1020)
## phase portrait
## margins:  [default is c(b,l,t,r) = c(5, 4, 4, 2) + 0.1]
##par(mar = rep(2,4))
pp_plot(traj, cols=cols, skip=10)
r.sigma <- model$r.sigma
h.sigma <- model$h.sigma
legend.text <- latex2exp::TeX(sprintf("$\\sigma_r = %g,\\,\\sigma_h = %g$", r.sigma, h.sigma))
legend("topright", bty="n", legend=legend.text)

## overall title:
stopTime <- model$stopTime
K <- model$K
title.string <- sprintf("Trajectory up to time %.0f (of %.0f)\nK = %g",
                        tmax, stopTime, K)
title(main=title.string)
##mtext(title.string
##      , outer=TRUE
##      ##, cex=2
##      )
##par(cex=cex.orig)
##par(oma=oma.orig)

## ANNOTATION IN TOP LEFT PANEL
cex.orig <- par(cex=1.5)
mar.orig <- par(mar=rep(0.1,4))
plot(NA,NA, type="n", bty="n", xlim=c(0,1), ylim=c(0,1),
     xaxt="n", yaxt="n")
legend("topleft", bty="n", legend=legend.text)
par(cex=cex.orig)
par(mar=mar.orig)

} # end main loop over i

if (!interactive()) dev.off()
