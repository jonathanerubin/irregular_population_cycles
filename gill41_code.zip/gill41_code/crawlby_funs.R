## 11 Feb 2020, Pitt
##
## 1. run Gillespie or adaptive tau simulations of the predator-prey
## model we are studying in order to investigate saddle crawl-bys as a
## mechanism for transient dynamics.
##
## 2. convert output to an SIRts object so I can use sirr to make
## plots.

library(adaptivetau)

#' @description Predator-prey model
#' @param r prey intrinsic reproductive rate
#' @param algorithm one of \code{"ODE"}, \code{"adaptive.tau"},
#'     \code{"exact"}
#' @param rStoch (logical) if \code{TRUE}, \code{r} is stochastically
#'     driven by environmental noise
#' @param r.gamma scale parameter in Cox-Ingersoll-Ross model
#'     (https://en.wikipedia.org/wiki/Cox%E2%80%93Ingersoll%E2%80%93Ross_model)
#'     for noise in \code{r}
#' @param r.sigma noise parameter in Cox-Ingersoll-Ross model for
#'     noise in \code{r}
#' @param K prey carrying capacity (population scale)
#' @param a consumption rate (per prey per predator)
#' @param hOverK handling parameter (scaled by \code{K})
#' @param preyPerPredator number of prey that get consumed to produce
#'     one new predator
#' @param m predator mortality rate (\code{1/m} is the mean predator
#'     lifetime)
#' @param immigration.rate added to consumption rate to ensure
#'     predators do not go extinct
#' @param message.interval number of \code{rate_fun} calls between
#'     messages indicating progress of run
#' @note Efficiency of conversion of prey biomass into predator
#'     biomass is \code{b = 1/preyPerPredator}.  A sensible
#'     immigration rate is \code{a*b}, which is \code{1} for the
#'     default parameter values; this is sensible because it is the
#'     consumption rate as the number of prey goes to infinity and
#'     there is only one predator.
#' @return
#' @export
create_PredatorPreyModel <-
    function(r = 1,
             algorithm = "adaptive.tau",
             rStoch = FALSE,
             hStoch = FALSE,
             r.gamma = 1,
             r.sigma = 0.1,
             h.gamma = 1,
             h.sigma = 0.1,
             K = 1,
             a = 2,
             hOverK = 0.15,
             preyPerPredator = 2,
             m = 0.6,
             immigration.rate = 0,
             inits = c(prey = K/100, pred = K/200),
             startTime = 0,
             stopTime = 500,
             clockTick = 0.5,
             message.interval = 10^4
             ) {
        h <- hOverK * K
        stopifnot(preyPerPredator > 0)
        b <- 1 / preyPerPredator # efficiency of conversion of prey biomass into predator biomass
        transitions <- list(c(prey = +1)            # trans 1: prey grows
                          , c(prey = -1)            # trans 2: prey decays
                          , c(prey = -preyPerPredator, pred = +1) # trans 3: predation
                          , c(pred = -1)            # trans 4: predator dies
                          , c(prey = preyPerPredator, pred = +1)  # trans 5: immigration
                            )
        vector_field <- function(t, y, parms) {
            with(as.list(y,parms),{
                xx <- prey
                yy <- pred
                consumption.rate <- b*a*xx*yy/(xx+h)
                dx <- r*xx*(1-xx/K) - consumption.rate/b
                dy <- consumption.rate - m*yy
                return(list(c(dx=dx, dy=dy)))
            })
        }
        ## FIX: these are reset in ssa_PredatorPrey(); do I need this here?
        tlast <<- 0 # so we know how long since last event
        icall <<- 0 # count tau-leaps or Gillespie events
        tvec <<- numeric(2) # hold last time and current time
        ## FIX: allocating saves lots of time, but can crash...
        ## tauvec <<- numeric(300000) # to save all tau-leaps
        rval.last <<- NA # so we can save the distribution of r values
        rval.last.time <<- NA # save time at which rval.last was computed
        hval.last <<- NA # so we can save the distribution of h values
        hval.last.time <<- NA # save time at which hval.last was computed
        step.num <<- 0 # event counter; FIX: duplicates icall but used differently
        ## FIX: rate_fun should be defined outside the creation of the model
        rate_fun <- function(x, parms, t) {
            icall <<- icall + 1
            tvec[1] <<- tvec[2]
            tvec[2] <<- t
            tdiff <- diff(tvec)
            ##tdiff <- t - tlast
            ##message("*t: ", t, ", tlast: ", tlast, ", tdiff: ", tdiff, ", icall: ", icall)
            ##tlast <<- t
            tlast <<- tvec[1]
            ##message(" t: ", t, ", tlast: ", tlast, ", tdiff: ", tdiff)
            ##tauvec[icall] <<- tdiff # save all tau-leaps
            if (icall %% parms$message.interval == 0) {
                cpu.time <- cpu_string()
                my.message <- sprintf("rate_fun:  t    icall r.sigma h.sigma CPU.time\n%12.5f %8d %7.1g %7.1g %s",
                                      t, icall, parms$r.sigma, parms$h.sigma, cpu.time)
                message(my.message)
                if (icall %% (parms$message.interval*10) == 0) {
                    save(icall, x, parms, t, tlast, tvec, cpu.time,
                         file=sprintf("progress_%.1f_%.1f.RData", parms$r.sigma, parms$h.sigma))
                }
            }
            with(parms, {
                xx <- x["prey"]
                yy <- x["pred"]

                ## FIX: the code is almost identical for noise in r
                ## and noise in h: create a function for noise in any
                ## parameter


                ##############################
                ## ENVIRONMENTAL NOISE IN r ##
                ##############################
                ##
                ## Gillespie assumes rate parameters are fixed.  In order to deal with stochastically varying parameters, I
                ## am following Todd's suggestion in his message of 1 Sep 2020 in thread "crawlby: CIR process for
                ## environmental noise".  Here is the critical part of his message:
                ##
                ## Unless the typical length of the inter-jump times in the Markov model is quite long (I’m suspecting the
                ## contrary), I’d advise against using the stationary distribution.  My analytical predictions (which are
                ## aligning with Jon’s simulations) are showing that autocorrelation in the input noise is a determining
                ## factor in the variance of the output noise (variability in cycle length), so what I’d suggest doing is an
                ## Euler-Maruyama numerical scheme based on the jump times in the Markov chain.
                ## [cf. https://en.wikipedia.org/wiki/Euler-Maruyama_method]
                ##
                ## 1. Draw initial condition p_0 from the stationary distribution
                ## 2. Generate the first jump time in the Gillespie algorithm, t_1, using p_0 for the appropriate rate.
                ## 3. Draw W_1 from a Normal(0,1) distribution
                ## 3. Generate p_1 = p(t_1) = p_0 + gamma*(barp - p_0)*t_1 + sigma*sqrt(p_0*t)*W_1
                ## 4. Generate t_2 using p_1, etc.
                ##
                ##rval <- if (rStoch) rnorm( n=1, mean=r, sd=r.sigma) else r
                if (rStoch) {# use Cox-Ingersoll-Ross model
                    if (tlast == 0) {# this is the first call, so use stationary disn
                        ## 1. Draw initial condition p_0 from the stationary distribution
                        rval <- sde::rsCIR( n=1, theta=c(r.gamma*r, r.gamma, r.sigma) )
                        rval.last <<- rval
                        rval.last.time <<- -999 # so I can identify tlast==0
                        ##message(sprintf("*tlast: %.4f, rval: %.4f, time: %.4f", tlast, rval, rval.last.time))
                        ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f\n", r, rval.last, r.gamma, tdiff, r.sigma))
                    } else {
                        ## 2. Generate the first jump time in the Gillespie algorithm, t_1, using p_0 for the appropriate rate.
                        ##    (t_1 is tdiff)
                        ## 3. Draw W_1 from a Normal(0,1) distribution
                        W1 <- rnorm(1)
                        ## 3. Generate p_1 = p(t_1) = p_0 + gamma*(barp - p_0)*t_1 + sigma*sqrt(p_0*t)*W_1
                        rval <- rval.last + r.gamma*(r - rval.last)*tdiff + r.sigma*sqrt(rval.last*tdiff)*W1
                        ## if the relationship gives p_1 < 0, then set p_1 = 0
                        if (rval < 0) rval <- 0
                        ## 4. Generate t_2 using p_1, etc.
                        rval.last <<- rval
                        rval.last.time <<- t
                        ##message(sprintf(" tlast: %.4f, rval: %.4f, time: %.4f", tlast, rval, rval.last.time))
                        ##cat("r  rval.last r.gamma   t   tdiff r.sigma W1\n")
                        ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f %.4f %.4f\n", r, rval.last, r.gamma, t, tdiff, r.sigma, W1))
                    }
                    ##cat("rate_fun: t tlast rval rval.last rval.last.time\n")
                    ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f\n", t, tlast, rval, rval.last, rval.last.time))
                } else {# deterministic
                    rval <- r
                }

                ##############################
                ## ENVIRONMENTAL NOISE IN h ##
                ##############################
                ## FIX: rescaling h is not very transparent
                ##
                ##hval <- if (hStoch) rnorm( n=1, mean=h, sd=h.sigma) else h
                if (hStoch) {# use Cox-Ingersoll-Ross model
                    if (tlast == 0) {# this is the first call, so use stationary disn
                        ## 1. Draw initial condition p_0 from the stationary distribution
                        hval <- sde::rsCIR( n=1, theta=c(h.gamma*hOverK, h.gamma, h.sigma) )
                        hval.last <<- hval
                        hval.last.time <<- -999 # so I can identify tlast==0
                        ##message(sprintf("*tlast: %.4f, hval: %.4f, time: %.4f", tlast, hval, hval.last.time))
                        ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f\n", h, hval.last, h.gamma, tdiff, h.sigma))
                    } else {
                        ## 2. Generate the first jump time in the Gillespie algorithm, t_1, using p_0 for the appropriate rate.
                        ##    (t_1 is tdiff)
                        ## 3. Draw W_1 from a Normal(0,1) distribution
                        W1 <- rnorm(1)
                        ## 3. Generate p_1 = p(t_1) = p_0 + gamma*(barp - p_0)*t_1 + sigma*sqrt(p_0*t)*W_1
                        hval <- hval.last + h.gamma*(hOverK - hval.last)*tdiff + h.sigma*sqrt(hval.last*tdiff)*W1
                        ## if the relationship gives p_1 < 0, then set p_1 = 0
                        if (hval < 0) hval <- 0
                        ## 4. Generate t_2 using p_1, etc.
                        hval.last <<- hval
                        hval.last.time <<- t
                        ##message(sprintf(" tlast: %.4f, hval: %.4f, time: %.4f", tlast, hval, hval.last.time))
                        ##cat("h  hval.last h.gamma   t   tdiff h.sigma W1\n")
                        ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f %.4f %.4f\n", h, hval.last, h.gamma, t, tdiff, h.sigma, W1))
                    }
                    ##cat("rate_fun: t tlast hval hval.last hval.last.time\n")
                    ##cat(sprintf("%.4f %.4f %.4f %.4f %.4f\n", t, tlast, hval, hval.last, hval.last.time))
                    hval <- hval * K # because we were really dealing with hOverK
                } else {# deterministic
                    hval <- h
                }
                if (step.num < step.num.max) {
                    step.num <<- step.num+1
                    rvals.df[step.num,] <<- c(t, rval)
                    hvals.df[step.num,] <<- c(t, hval)
                }
                #####################################
                ## END ENVIRONMENTAL STOCHASTICITY ##
                #####################################

                ## Note: The logical expressions below prevent negative prey
                ##       or predator population sizes.
                if (xx <= K) {
                    prey.growth.rate <- rval*xx*(1-xx/K)
                    prey.decay.rate <- 0
                } else {
                    prey.growth.rate <- 0
                    prey.decay.rate <- -rval*xx*(1-xx/K)
                }
                consumption.rate <- b*a*xx*yy/(xx+hval)*(xx >= preyPerPredator)
                predator.death.rate <- m*yy
                return( c(prey.growth.rate, prey.decay.rate,
                          consumption.rate, predator.death.rate,
                          immigration.rate) )
            })
        }
        
        ## co-existence equilibrium
        xeqm <- h*m/(a*b-m)
        yeqm <- (b*h*(a*b*K - (h + K)*m)*r)/(K*(-(a*b) + m)^2)
        equilibrium <- c(x=xeqm, y=yeqm)
        
        ## Hopf period
        HopfPeriod <- 2*pi*sqrt((a*b+m)/((a*b-m)*m*r))

        model <- list(r=r, K=K, a=a, hOverK=hOverK, h=h, b=b, m=m,
                      algorithm=algorithm,
                      rStoch=rStoch,
                      hStoch=hStoch,
                      r.gamma=r.gamma,
                      r.sigma=r.sigma,
                      h.gamma=h.gamma,
                      h.sigma=h.sigma,
                      preyPerPredator=preyPerPredator,
                      transitions = transitions,
                      rate_fun = rate_fun,
                      vector_field = vector_field,
                      inits = inits,
                      equilibrium = equilibrium,
                      HopfPeriod = HopfPeriod,
                      startTime = startTime,
                      stopTime = stopTime,
                      clockTick = clockTick,
                      message.interval = message.interval)
        class(model) <- c("predator-prey model", "list")
        return(model)
    }

ode_PredatorPrey <- function( model, ntimes=1000 ) {
    with(model, {
        times <- seq(startTime, stopTime, length=ntimes)
        ## deSolve::ode requires the first time to be the initial
        ## time, but if the next time is far in the future, it crashes
        ## because maxstep is too small.  So, I'm removing the
        ## transient after the fact.
        out <- deSolve::ode(inits, times, func=vector_field,
                            parms=model ##, method=lsoda, 
                            )
        res <- as.data.frame(out)
        if (startTime > 0) res <- res[times >= startTime,]
        res <- data.frame(res, x=res$prey/K, y=res$pred/K, clock=NA)
        res <- insert_clock_ticks( res, model, time.var="time" )
        attr(res, "model") <- model
        attr(res, "type") <- "ODE"
        class(res) <- c("ppts", class(res)) # ppts = predator-prey time series
        return(res)
    })
}

##' @param algorithm character string indicating type of stochastic
##'     simulation algorithm (\code{"adaptive.tau"}, \code{"exact"})
ssa_PredatorPrey <- function( model, seed = as.numeric(Sys.time()) ) {
    algorithm <- model$algorithm
    ptm <- proc.time()
    message("ssa_PredatorPrey:\n\talgorithm = ", algorithm, ", seed = ", seed,
            ", r.sigma = ", model$r.sigma, ", h.sigma = ", model$h.sigma)
    ssa.algorithm <- switch(algorithm,
                            adaptive.tau = ssa.adaptivetau,
                            exact = ssa.exact,
                            NULL)
    if (is.null(ssa.algorithm)) stop("unknown ssa algorithm '", algorithm, "'")
    ## sr = simulation results
    sr <- ssa.algorithm(init.values = model$inits,
                          model$transitions,
                          model$rate_fun,
                          params = model,
                          tf = model$stopTime)
    message("ssa_PredatorPrey:\n\tcompleted ", algorithm, "\n\tr.sigma = ",
            model$r.sigma, ", h.sigma = ", model$h.sigma,
            "\n\tcpu time = ", cpu_string(startTime = ptm))
    K <- model$K
    out <- data.frame(t = sr[,"time"], x=sr[,"prey"]/K, y=sr[,"pred"]/K,
                      clock=NA) # NA so column is there to be filled in below
    ptm.clockTick.start <- proc.time()
    out <- insert_clock_ticks( out, model )
    cts <- cpu_string(startTime = ptm.clockTick.start)
    message("ssa_PredatorPrey: COMPLETED clockTick loop\n\tr.sigma = ",
            model$r.sigma, ", h.sigma = ", model$h.sigma,
            "\n\tcpu time = ", cts)
    ptm <- proc.time() - ptm
    attr(out, "model") <- model
    attr(out, "proc.time") <- ptm
    attr(out, "type") <- "Stochastic"
    attr(out, "seed") <- seed
    ##attr(out, "tauvec") <- tauvec
    attr(out, "rvals") <- rvals.df
    hvals.df[,"h"] <- hvals.df[,"h"] / K # actually save hOverK
    attr(out, "hvals") <- hvals.df
    class(out) <- c("ppts", class(out)) # ppts = predator-prey time series
    return(out)
}

##' Identify clock time times an insert them in data frame.
##' This is far too slow when we look at every event, so we
##' skip ahead reasonably.
##' @export
insert_clock_ticks <- function( x, model, time.var="t" ) {
    clockTick <- model$clockTick
    xt <- x[,time.var] # it is *much* faster to deal with a vector
    ###################################
    ## FIX: don't really need this bit:
    mean.dt <- mean(diff(xt)) # 0.000478 = mean(dt) from diagnostic histogram (tau_hist)
    events.per.clockTick <- round(clockTick / mean.dt)
    message("insert_clock_ticks:\n",
            "\tclockTick: ", clockTick, "\n",
            "\tmean.dt: ", mean.dt, "\n",
            "\tevents.per.clockTick: ", events.per.clockTick, "\n"
            )
    ###################################
    w <- which(diff(floor(xt/clockTick))==1) ## +1 ? before/after?
    tickvec <- rep(NA_real_,length(xt))
    tickvec[w] <- xt[w]
    x[,"clock"] <- tickvec
    return(x)
}

SLOW_insert_clock_ticks <- function( x, model, time.var="t" ) {
    clockTick <- model$clockTick
    ## FIX: this is a hack to speed this up enormously:
    mean.dt <- 0.000478 # mean(dt) from diagnostic histogram (tau_hist)
    events.per.clockTick <- round(clockTick / mean.dt)
    ## jump ahead this many events after setting tick time:
    jump.after.clockTick <- 0 # round(0.9 * events.per.clockTick)
    ## check only every istep steps:
    istep <- 1 # 10
    message("insert_clock_ticks:\n",
            "\tclockTick: ", clockTick, "\n",
            "\tmean.dt: ", mean.dt, "\n",
            "\tevents.per.clockTick: ", events.per.clockTick, "\n",
            "\tjump.after.clockTick: ", jump.after.clockTick, "\n",
            "\tistep: ", istep)
    i <- 1
    xt <- x[,time.var] # it is *much* faster to deal with a vector
    tnext <- xt[i]
    n <- min(length(xt), 10^5) # too slow to go through > 10^7 events
    while (i <= n) {
        if (xt[i] > tnext) {
            x[i,"clock"] <- xt[i]
            tnext <- tnext + clockTick
            i <- i + jump.after.clockTick
        }
        i <- i + istep
    }
    return(x)
}

#' Draw equilibria on phase portrait
#' @param model a predator-prey model object
#' @export
draw_pp_equilibria <- function( model ) {
    with(model, {
        ## co-existence equilibrium:
        xeqm <- equilibrium["x"] / K
        yeqm <- equilibrium["y"] / K
        cat("x eqm = ", xeqm, "\n")
        cat("y eqm = ", yeqm, "\n")
        ## x nullcline is just vertical line at xeqm:
        abline(v = xeqm, col="cyan")
        ## y nullcline is a curve:
        yfun <- function(x) {r*(1-x)*(x+hOverK)/a}
        curve(yfun, col="magenta", add=TRUE)
        ## co-existence equilibrium point:
        points(xeqm,yeqm, pch=21, bg="darkred")
        ## predator-free equilibrium:
        points(1,0, pch=21, bg="white", xpd=NA)
        ## both-free equilibrium:
        points(0,0, pch=21, bg="white", xpd=NA)
    })
}

#' time plot for predator-prey time series
ts_plot <- function(x,
                    type="l",
                    xlab="time",
                    ylab="Counts (log scale)",
                    las=1,
                    log="y",
                    main=NULL,
                    ... ) {
    time.var <- if (attr(x, "type") == "ODE") "time" else "t"
    if (is.null(main)) {
        mm <- attr(x,"model")
        main <- paste0( attr(x,"type"), " (K=", mm$K, ", tf=", mm$stopTime, ")")
    }
    matplot(x[,time.var], x[,c("x","y")],
            type=type, xlab=xlab, ylab=ylab, main=main, las=las, log=log, ...)
    legend("topleft", bty="n", legend=c("prey", "predator"), lty=1:2, col=1:2)
}

#' histogram of tau leaps for predator-prey time series
tau_hist <- function(x,
                    xlab="Time step dt",
                    ylab="Frequency", ##"Frequency (log scale)",
                    las=1,
                    main=NULL,
                    quantile.max=0.99,
                    ... ) {
    time.var <- if (attr(x, "type") == "ODE") "time" else "t"
    tdiff <- diff(x[,time.var])
    message("tau_hist: n = ", length(tdiff))
    print(summary(tdiff))
    ## ignore top 1% quantile:
    tdiff <- subset(tdiff, tdiff < quantile(tdiff,quantile.max))
    message("tau_hist: after dropping top 1%, n = ", length(tdiff))
    mm <- attr(x,"model")
    if (is.null(main)) {
        algorithm <- if (is.null(mm$algorithm)) "exact" else mm$algorithm
        main <- sprintf("%s %s\n(K = %g, tf = %g, seed = %g)",
                        if (mm$rStoch) {"r-Stoch"} else {""},
                        switch(algorithm,
                               exact = "Gillespie",
                               adaptive.tau = "adaptive.tau",
                               ODE = "ODE",
                               "??algorithm??"),
                        mm$K, mm$stopTime, seed)
        message("title: ", main)
    }
    hist(tdiff, xlab=xlab, ylab=ylab, main=main, las=las, ...)
    legend("topright", bty="n",
           legend=c(
               sprintf("n.steps = %g", length(tdiff)),
               sprintf("qmax = %g", quantile.max),
               sprintf("mean(dt) = %.3g", mean(tdiff)),
               sprintf("sd(dt) = %.3g", sd(tdiff))
           )
           )
    legend("topleft",bty="n",
           legend=latex2exp::TeX(sprintf(
                                 "$\\sigma_r = %g,\\,\\sigma_h = %g$", mm$r.sigma, mm$h.sigma))
           )
}

#' histogram of r values for predator-prey time series
r_hist <- function(x,
                    xlab="r",
                    ylab="Frequency", ##"Frequency (log scale)",
                    las=1,
                    main=NULL,
                    ##quantile.max=0.99,
                    ... ) {
    ##time.var <- if (attr(x, "type") == "ODE") "time" else "t"
    t <- attr(x,"rvals")[,"t"]
    rvec <- attr(x,"rvals")[,"r"]
    message("r_hist: n = ", length(t))
    ## ignore top 1% quantile:
    ##tdiff <- subset(tdiff, tdiff < quantile(tdiff,quantile.max))
    ##message("tau_hist: after dropping top 1%, n = ", length(tdiff))
    mm <- attr(x,"model")
    if (is.null(main)) {
        algorithm <- if (is.null(mm$algorithm)) "exact" else mm$algorithm
        main <- sprintf("%s %s\n(K = %g, tf = %g, seed = %g)",
                        if (mm$rStoch) {"r-Stoch"} else {""},
                        switch(algorithm,
                               exact = "Gillespie",
                               adaptive.tau = "adaptive.tau",
                               ODE = "ODE",
                               "??algorithm??"),
                        mm$K, mm$stopTime, seed)
        message("title: ", main)
    }
    hist(rvec, xlab=xlab, ylab=ylab, main=main, las=las, ...)
    legend("topright", bty="n",
           legend=c(sprintf("n.steps = %g", sum(!is.na(rvec)))
                    , sprintf("mean(r) = %g", mean(rvec,na.rm=TRUE))
                    , sprintf("sd(r) = %g", sd(rvec,na.rm=TRUE))
                    )
           )
    legend("topleft",bty="n",
           legend=latex2exp::TeX(sprintf(
                                 "$\\sigma_r = %g,\\,\\sigma_h = %g$", mm$r.sigma, mm$h.sigma))
           )
}

#' histogram of h values for predator-prey time series
h_hist <- function(x,
                    xlab="h",
                    ylab="Frequency", ##"Frequency (log scale)",
                    las=1,
                    main=NULL,
                    ##quantile.max=0.99,
                    ... ) {
    ##time.var <- if (attr(x, "type") == "ODE") "time" else "t"
    t <- attr(x,"hvals")[,"t"]
    hvec <- attr(x,"hvals")[,"h"]
    message("h_hist: n = ", length(t))
    ## ignore top 1% quantile:
    ##tdiff <- subset(tdiff, tdiff < quantile(tdiff,quantile.max))
    ##message("tau_hist: after dropping top 1%, n = ", length(tdiff))
    mm <- attr(x,"model")
    if (is.null(main)) {
        algorithm <- if (is.null(mm$algorithm)) "exact" else mm$algorithm
        main <- sprintf("%s %s\n(K = %g, tf = %g, seed = %g)",
                        if (mm$hStoch) {"h-Stoch"} else {""},
                        switch(algorithm,
                               exact = "Gillespie",
                               adaptive.tau = "adaptive.tau",
                               ODE = "ODE",
                               "??algorithm??"),
                        mm$K, mm$stopTime, seed)
        message("title: ", main)
    }
    hist(hvec, xlab=xlab, ylab=ylab, main=main, las=las, ...)
    legend("topright", bty="n",
           legend=c(sprintf("n.steps = %g", sum(!is.na(hvec)))
                    , sprintf("mean(h) = %g", mean(hvec,na.rm=TRUE))
                    , sprintf("sd(h) = %g", sd(hvec,na.rm=TRUE))
                    )
           )
    legend("topleft",bty="n",
           legend=latex2exp::TeX(sprintf(
                                 "$\\sigma_r = %g,\\,\\sigma_h = %g$", mm$r.sigma, mm$h.sigma))
           )
}

#' Phase portrait for predator-prey time series
pp_plot <- function( x, col.ode="red", log=""
                  , skip=1
                    ##, origin.region=c(xmax=0.12, ymax=0.07) # r noise
                  , origin.region=c(xmax=0.2,  ymax=0.12) # h noise
                    ##, carrying.capacity.region=c(xmin=0.6, ymax=0.13) # r noise
                  , carrying.capacity.region=c(xmin=0.5, ymax=0.15) # h noise
                    ##, y.nullcline.region=c(ymin=0.22, slope=0.55, yintercept=0) # r noise
                  , y.nullcline.region=c(ymin=0.23, slope=1, yintercept=-0.2) # h noise
                  , cols=NULL
                  , lwd.region=3
## exit from the “unstable manifold” region/entry to the “y-nullcline” region:  y=0.55x
## exit from the “y-nullcline” region/entry near the y-axis:  y=0.22
                  , ... ) {
    if (is.null(cols))
        cols <- c(origin="darkred", region2="grey", cc="darkblue",
                  region4="grey", yn="yellow", region6="grey")

    mm <- attr(x, "model")
    odeOut <- ode_PredatorPrey( mm )
    xode <- odeOut$x
    yode <- odeOut$y
    xlim <- range( range(x$x), range(xode), 1 )
    if (substr(log,1,1) != "x") xlim <- range(0, xlim)
    ylim <- range( range(x$y), range(yode), 0.37 )
    plot(NA, NA, type="n", las=1, xlab="x", ylab="y",
         xaxs="i", yaxs="i", xlim=xlim, ylim=ylim, log=log, ...)
    draw_pp_equilibria( mm )
    if (skip > 1) {# retain only every skip points
        require(dplyr)
        x$irow <- attr(x,"row.names")
        x <- x %>% filter(irow %% skip == 0)
        message("pp_plot: skip = ", skip, ", nrow(x) = ", nrow(x))
    }
    lines(x[,"x"], x[,"y"])
    ## ssa clock:
    xclock <- subset(x, !is.na(clock))
###with(xclock, points(x, y, pch=21, bg="red", cex=0.5, xpd=NA))
    ## ode solution:
###with(odeOut, lines(xode, yode, col=col.ode))
###message("pp_plot: ODE trajectory plotted")
    ## ode clock:
    odeclock <- subset(odeOut, !is.na(clock))
    with(odeclock, points(x, y, pch=21, bg="yellow", cex=0.5, xpd=NA))
    ##r.sigma <- attr(trajset[[1]]$traj,"model")$r.sigma
    ##legend("topright",bty="n",legend=sprintf("r.sigma = %g", r.sigma))
    with(as.list(origin.region), {
        lines(x=c(0,xmax,xmax), y=c(ymax,ymax,0), col=cols["origin"], lwd=lwd.region)
    })
    with(as.list(carrying.capacity.region), {
        lines(x=c(xmin,xmin,1), y=c(0,ymax,ymax), col=cols["cc"], lwd=lwd.region)
    })
    with(as.list(y.nullcline.region), {
        lines(x=c(0,(ymin-yintercept)/slope,(1-yintercept)/slope), y=c(ymin,ymin,1), col=cols["yn"], lwd=lwd.region)
    })
}

##' Residence times for a predator-prey time series
##'
##' Compute the time a trajectory spends in each box in a grid on the
##' plane.
##'
##' @param ppts a predator-prey time series (\code{ppts} object)
##' @param origin.region \code{x} and \code{y} upper limits of region
##'     "near the origin" (see \code{details})
##' @details \code{origin.region} is a named vector of the form
##'     \code{c(xmax=x,ymax=y)}.  A trajectory is consider to have
##'     entered the region near the origin when it crosses the line
##'     \code{y=ymax} and to have existed the region near the origin
##'     when it crosses the line \code{x=xmax}.  Similarly for
##'     \code{carrying.capacity.region}, except the format is
##'     \code{c(xmin=x, ymax=y)}
##' @export
residence_times <- function( ppts ) {

    message("computing y nullcline residence times...")
    yn <- compute_region_times( ppts, "y.nullcline" )

    message("computing origin residence times...")
    origin <- compute_region_times( ppts, "origin" )

    message("computing carrying capacity residence times...")
    cc <- compute_region_times( ppts, "carrying.capacity" )

    reg <- list()
    for (ireg in c(2,4,6)) {
        message("computing region ", ireg, " residence times...")
        reg[[ireg]] <- compute_region_times( ppts, paste0("region",ireg) )
    }

    message("computing cycle times...")
    eet <- origin$entry.exit.times
    require(dplyr)
    eet <- eet %>% filter(!is.na(entry.time))
    cycle.times <- diff(eet[,"entry.time"])

    out <- list(
        origin.entry.exit.times = origin$entry.exit.times
      , origin.times = origin$restimes
      , cc.entry.exit.times = cc$entry.exit.times
      , cc.times = cc$restimes
      , yn.entry.exit.times = yn$entry.exit.times
      , yn.times = yn$restimes
      , reg2.entry.exit.times = reg[[2]]$entry.exit.times
      , reg2.times = reg[[2]]$restimes
      , reg4.entry.exit.times = reg[[4]]$entry.exit.times
      , reg4.times = reg[[4]]$restimes
      , reg6.entry.exit.times = reg[[6]]$entry.exit.times
      , reg6.times = reg[[6]]$restimes
      , cycle.times = cycle.times
      , model = attr(ppts,"model")
      , sigma = attr(ppts,"sigma")
    )
    return(out)
}    

compute_region_times <- function( ppts, region
     ##, origin.region=c(xmax=0.12, ymax=0.07) # r noise
     , origin.region=c(xmax=0.2,  ymax=0.12) # h noise
     ##, carrying.capacity.region=c(xmin=0.6, ymax=0.13) # r noise
     , carrying.capacity.region=c(xmin=0.5, ymax=0.15) # h noise
     ##, y.nullcline.region=c(ymin=0.22, slope=0.55, yintercept=0) # r noise
     , y.nullcline.region=c(ymin=0.23, slope=1, yintercept=-0.2) # h noise
    ) {
    ## make it easier to refer to points:
    x <- ppts$x
    y <- ppts$y
    t <- ppts$t
    ## add columns for entry and exit times
    ppts$entry.time <- NA
    ppts$exit.time <- NA

    ## shifted versions of x and y contain previous values
    ## xprev[i] == x[i-1] etc
    xprev <- c(NA,x)
    yprev <- c(NA,y)
    x <- c(x,NA)
    y <- c(y,NA)

    if (region == "origin") {
        rx <- origin.region["xmax"]
        ry <- origin.region["ymax"]
        ## identify entry and exit times
        entered <- yprev >= ry & y < ry & x < rx
        exited <- xprev < rx & yprev < ry & x >= rx
    } else if (region == "region2") {
        rx <- origin.region["xmax"]
        ry <- origin.region["ymax"]
        ccrx <- carrying.capacity.region["xmin"]
        ccry <- carrying.capacity.region["ymax"]
        ## identify entry and exit times
        entered <- xprev < rx & yprev < ry & x >= rx
        exited <- xprev <= ccrx & x > ccrx & y < ccry
    } else if (region == "carrying.capacity") {
        rx <- carrying.capacity.region["xmin"]
        ry <- carrying.capacity.region["ymax"]
        ## identify entry and exit times
        entered <- xprev <= rx & x > rx & y < ry
        exited <-  xprev > rx & yprev < ry & y >= ry
    } else if (region == "region4") {
        rx <- carrying.capacity.region["xmin"]
        ry <- carrying.capacity.region["ymax"]
        ynry <- y.nullcline.region["ymin"]
        ynrslope <- y.nullcline.region["slope"]
        ynrintercept <- y.nullcline.region["yintercept"]
        ## identify entry and exit times
        entered <- xprev > rx & yprev < ry & y >= ry
        exited <- yprev <= ynrslope*xprev + ynrintercept & y > ynrslope*x + ynrintercept & y > ynry
    } else if (region == "y.nullcline") {
        ry <- y.nullcline.region["ymin"]
        rslope <- y.nullcline.region["slope"]
        rintercept <- y.nullcline.region["yintercept"]
        ## identify entry and exit times
        entered <- yprev <= rslope*xprev + rintercept & y > rslope*x + rintercept & y > ry
        exited <-  yprev > rslope*xprev + rintercept & yprev > ry & y <= ry
    } else if (region == "region6") {
        ry <- y.nullcline.region["ymin"]
        rslope <- y.nullcline.region["slope"]
        rintercept <- y.nullcline.region["yintercept"]
        orx <- origin.region["xmax"]
        ory <- origin.region["ymax"]
        ## identify entry and exit times
        entered <- yprev > rslope*xprev + rintercept & yprev > ry & y <= ry
        exited <- yprev >= ory & y < ory & x < orx
    } else {
        stop("compute_region_times: region '", region, "' unknown")
    }
    ## remove first extra row added for shift
    entered <- entered[-1]
    exited <- exited[-1]
    ## add columns with entry and exit times
    ppts$entry.time <- ifelse(entered, t, NA)
    ppts$exit.time <- ifelse(exited, t, NA)
    message("Done computing ", region, " times.")

    require(dplyr)
    ## filter out times that are neither entry nor exit times:
    entry.exit.times <- (ppts
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    eet <- entry.exit.times
    message("compute_region_times: nrow(eet) = ", nrow(eet))
    ## remove successive entries
    eet[,"entry.time"] <- retain_firsts(eet[,"entry.time"])
    message("compute_region_times: entry count = ", length(eet[,"entry.time"]))
    ## remove successive exits
    eet[,"exit.time"] <- retain_firsts(eet[,"exit.time"])
    message("compute_region_times: exit count = ", length(eet[,"exit.time"]))
    ## filter out times that are neither entry nor exit times:
    eet <- (eet
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    ## make sure we start with an entry and end with an exit
    eet[1,"exit.time"] <- NA
    eet[nrow(eet),"entry.time"] <- NA
    ## filter out times that are neither entry nor exit times:
    eet <- (eet
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    entry.exit.times <- eet
        
    ## compute residence times in region
    neet <- nrow(entry.exit.times)
    message("compute_region_times: neet = ", neet)
    if (neet %% 2 != 0) stop("neet = ", neet, " (not divisible by 2)")
    restimes <- rep(NA,neet/2)
    dd <- entry.exit.times
    for (i in 1:length(restimes)) {
        restimes[i] <- dd[2*i, "exit.time"] - dd[2*i-1, "entry.time"]
    }
    return( list(entry.exit.times = entry.exit.times,
                 restimes = restimes) )
}

SLOW_compute_region_times <- function( ppts, region
                          , origin.region=c(xmax=0.12, ymax=0.07)
                          , carrying.capacity.region=c(xmin=0.6, ymax=0.13)
                          , y.nullcline.region=c(ymin=0.22, slope=0.55)
                                 ) {
    ## make it easier to refer to points:
    x <- ppts$x
    y <- ppts$y
    t <- ppts$t
    ## add columns for entry and exit times
    ppts$entry.time <- NA
    ppts$exit.time <- NA

    if (region == "origin") {
        orx <- origin.region["xmax"]
        ory <- origin.region["ymax"]
        ## identify entry and exit times
        for (i in 2:nrow(ppts)) {
            entered.origin <- y[i-1] >= ory && y[i] < ory && x[i] < orx
            exited.origin <- x[i-1] < orx && y[i-1] < ory && x[i] >= orx
            if (entered.origin) ppts$entry.time[i] <- t[i]
            if (exited.origin) ppts$exit.time[i] <- t[i]
        }
    } else if (region == "carrying.capacity") {
        rx <- carrying.capacity.region["xmin"]
        ry <- carrying.capacity.region["ymax"]
        ## identify entry and exit times
        for (i in 2:nrow(ppts)) {
            entered <- x[i-1] <= rx && x[i] > rx && y[i] < ry
            exited <-  x[i-1] > rx && y[i-1] < ry && y[i] >= ry
            if (entered) ppts$entry.time[i] <- t[i]
            if (exited) ppts$exit.time[i] <- t[i]
        }
    } else if (region == "y.nullcline") {
        ry <- y.nullcline.region["ymin"]
        rslope <- y.nullcline.region["slope"]
        ## identify entry and exit times
        for (i in 2:nrow(ppts)) {
            entered <- y[i-1] <= rslope*x[i-1] && y[i] > rslope*x[i] && y[i] > ry
            exited <-  y[i-1] > rslope*x[i-1] && y[i-1] > ry && y[i] <= ry
            if (entered) ppts$entry.time[i] <- t[i]
            if (exited) ppts$exit.time[i] <- t[i]
        }
    } else {
        stop("compute_region_times: region '", region, "' unknown")
    }
    message("Done computing ", region, " times.")

    require(dplyr)
    ## filter out times that are neither entry nor exit times:
    entry.exit.times <- (ppts
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    eet <- entry.exit.times
    message("compute_region_times: nrow(eet) = ", nrow(eet))
    ## remove successive entries
    eet[,"entry.time"] <- retain_firsts(eet[,"entry.time"])
    message("compute_region_times: entry count = ", length(eet[,"entry.time"]))
    ## remove successive exits
    eet[,"exit.time"] <- retain_firsts(eet[,"exit.time"])
    message("compute_region_times: exit count = ", length(eet[,"exit.time"]))
    ## filter out times that are neither entry nor exit times:
    eet <- (eet
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    ## make sure we start with an entry and end with an exit
    eet[1,"exit.time"] <- NA
    eet[nrow(eet),"entry.time"] <- NA
    ## filter out times that are neither entry nor exit times:
    eet <- (eet
        %>% filter(!is.na(entry.time) | !is.na(exit.time))
    )
    entry.exit.times <- eet
        
    ## compute residence times in region
    neet <- nrow(entry.exit.times)
    message("compute_region_times: neet = ", neet)
    if (neet %% 2 != 0) stop("neet = ", neet, " (not divisible by 2)")
    restimes <- rep(NA,neet/2)
    dd <- entry.exit.times
    for (i in 1:length(restimes)) {
        restimes[i] <- dd[2*i, "exit.time"] - dd[2*i-1, "entry.time"]
    }
    return( list(entry.exit.times = entry.exit.times,
                 restimes = restimes) )
}

##' Residence times for a predator-prey time series (OLD VERSION)
##'
##' Compute the time a trajectory spends in each box in a grid on the
##' plane.
##'
##' @param ppts a predator-prey time series (\code{ppts} object)
##' @param nx number of grid cells in \code{x}
##' @param ny number of grid cells in \code{y}
##' @param xlim x limits
##' @param ylim y limits
##' @param origin.region \code{x} and \code{y} upper limits of region
##'     "near the origin" (see \code{details})
##' @details \code{origin.region} is a named vector of the form
##'     \code{c(xmax=x,ymax=y)}.  A trajectory is consider to have
##'     entered the region near the origin when it crosses the line
##'     \code{y=ymax} and to have existed the region near the origin
##'     when it crosses the line \code{x=xmax}.  Similarly for
##'     \code{carrying.capacity.region}, except the format is
##'     \code{c(xmin=x, ymax=y)}
##' @export
residence_times_OLD <- function(ppts,
                            nx=10, ny=10,
                            xlim=c(0,1), ylim=c(0,1)
                          , origin.region=c(xmax=0.12, ymax=0.07)
                          , carrying.capacity.region=c(xmin=0.6, ymax=0.13)
                          , y.nullcline.region=c(ymin=0.22, slope=0.55)
                            ) {
    ## add grid cell location columns to ppts:
    ## just truncate x and y to nearest grid cell boundaries:
    x <- ppts$x
    y <- ppts$y
    ## FIX: assuming xlim and ylim are c(0,1):
    ppts$ix <- ceiling( x * nx )
    ppts$iy <- ceiling( y * ny )
    ppts$xg <- ppts$ix / nx
    ppts$yg <- ppts$iy / ny
    ## maybe not worth worrying about xlim and ylim... just plot the part of the grid we want

    ## add column for total time in grid cell before moving to another
    ## (we will filter out non-NA rows later)
    ppts$cell.time <- NA
    ## also add columns for time in region of origin as defined by Jon's sections
    ppts$origin.entry.time <- NA
    ppts$origin.exit.time <- NA
    orx <- origin.region["xmax"]
    ory <- origin.region["ymax"]
    ## now just add the time difference between grid cell changes
    xg <- ppts$xg
    yg <- ppts$yg
    t <- ppts$t
    tlast <- t[1]
    xglast <- xg[1]
    yglast <- yg[1]
    for (i in 2:nrow(ppts)) {
        moved.to.different.cell <- xg[i] != xg[i-1] || yg[i] != yg[i-1]
        if (moved.to.different.cell) {
            is.previous.cell <- xg[i] == xglast && yg[i] == yglast
            ## don't count this if we just moved back to the previous cell:
            if (!is.previous.cell) ppts$cell.time[i-1] <- t[i] - tlast
            tlast <- t[i]
            xglast <- xg[i]
            yglast <- yg[i]
        }
        entered.origin <- y[i-1] >= ory && y[i] < ory && x[i] < orx
        exited.origin <- x[i-1] < orx && y[i-1] < ory && x[i] >= orx
        if (entered.origin) ppts$origin.entry.time[i] <- t[i]
        if (exited.origin) ppts$origin.exit.time[i] <- t[i]
    }

    ## how long trajectories spend in each cell before moving on:
    require(dplyr)
    traj.cell.times <- (ppts
        %>% filter(!is.na(cell.time))
        ##%>% group_by(xg, yg)
        %>% group_by(ix, iy)
    )
    traj.cell.times.total <- (traj.cell.times
        %>% summarise( res.time = sum(cell.time), n = n())
    )
    ## all residence times near origin
    traj.cell.times.origin <- (traj.cell.times
        %>% filter(ix == 1 & iy == 1)
    )
    ## all residence times near (K,0)
    traj.cell.times.K.0 <- (traj.cell.times
        %>% filter(ix == nx & iy == 1)
    )

    ## filter out times that are neither origin entry nor exit times:
    origin.entry.exit.times <- (ppts
        %>% filter(!is.na(origin.entry.time) | !is.na(origin.exit.time))
    )
    oeet <- origin.entry.exit.times
    ## remove successive entries
    oeet[,"origin.entry.time"] <- retain_firsts(oeet[,"origin.entry.time"])
    ## remove successive exits
    oeet[,"origin.exit.time"] <- retain_firsts(oeet[,"origin.exit.time"])
    ## filter out times that are neither entry nor exit times:
    oeet <- (oeet
        %>% filter(!is.na(origin.entry.time) | !is.na(origin.exit.time))
    )
    ## make sure we start with an entry and end with an exit
    oeet[1,"origin.exit.time"] <- NA
    oeet[nrow(oeet),"origin.entry.time"] <- NA
    ## filter out times that are neither entry nor exit times:
    oeet <- (oeet
        %>% filter(!is.na(origin.entry.time) | !is.na(origin.exit.time))
    )
    origin.entry.exit.times <- oeet
        
    ## compute residence times near origin
    ## FIX: should check length(origin.entry.exit.times) is divisible by 2
    origin.times <- rep(NA,floor(nrow(origin.entry.exit.times)/2))
    dd <- origin.entry.exit.times
    for (i in 1:length(origin.times)) {
        origin.times[i] <- dd[2*i, "origin.exit.time"] - dd[2*i-1, "origin.entry.time"]
    }

    out <- traj.cell.times.total
    attr(out, "nx") <- nx
    attr(out, "ny") <- ny
    attr(out, "origin.counts") <- traj.cell.times.origin
    attr(out, "K.0.counts") <- traj.cell.times.K.0
    attr(out, "origin.entry.exit.times") <- origin.entry.exit.times
    attr(out, "origin.times") <- origin.times
    attr(out, "ppts") <- ppts # FIX: for debugging
    return(out)
}    

#' @description Retain only the first of successive non-\code{NA}
#'     elements
#'
#' Replace non-\coe{NA}s after the first with \code{NA}.
#' For example, \code{c(NA,1,1,1,NA,2,2)} becomes
#' \code{c(NA,1,NA,NA,NA,2,NA)}.
#' @param x a vector
#' @return
#' @export
retain_firsts <- function(x) {
    if (all(is.na(x))) return(x)
    ## we know there is at least one non-NA
    i <- 1
    n <- length(x)
    while (i < n) {
        ## find next non-NA:
        while (i<n && is.na(x[i])) i <- i+1
        ## x[i] is non-NA and i is at most n
        while (i<n && !is.na(x[i+1])) {
            i <- i+1
            x[i] <- NA
        }
        i <- i+1
    }
    return(x)
}

get_grid <- function(nx=10, ny=10,
                     xlim=c(0,1), ylim=c(0,1) ) {
    ## grid points in x and y:
    xg <- seq( xlim[1], xlim[2], length.out = nx+1 )
    yg <- seq( ylim[1], ylim[2], length.out = ny+1 )
    ## remove end points because we are counting in cells:
    xg <- xg[-1]
    yg <- xg[-1]
    ## list of grid cells (via top right corner coordinate):
    eg <- expand.grid( x=xg, y=yg )
    ## output data frame will contain residence times column
    out <- data.frame( eg )
    return(out)
}

get_matrix <- function( rr ) {# rr = residence time data frame

    nx <- attr(rr, "nx")
    ny <- attr(rr, "ny")
    ix.max <- max(rr[,"ix"], na.rm=TRUE)
    iy.max <- max(rr[,"iy"], na.rm=TRUE)
    
    ##mat <- matrix(nrow=nx, ncol=ny)
    ## nx,ny are indeces of density K, not max
    mat <- matrix(nrow=max(nx,ix.max), ncol=max(ny,iy.max))
    for (ir in 1:nrow(rr)) {
        ix <- unlist(rr[ir,"ix"])
        iy <- unlist(rr[ir,"iy"])
        mat[ix,iy] <- unlist(rr[ir,"res.time"])
    }
    attr(mat, "nx") <- nx
    attr(mat, "ny") <- ny
    attr(mat, "ix.max") <- ix.max
    attr(mat, "iy.max") <- iy.max
    if (nx < ix.max) message("get_matrix: nx = ", nx, " < ", ix.max, " = ix.max")
    if (ny < iy.max) message("get_matrix: ny = ", ny, " < ", iy.max, " = iy.max")
    return(mat)
}

## RESIDENCE TIMES

##' @param seed random seed, specifiable for reproducibility
residence_time_matrix <- function(model,
                                  trajectory = ssa_PredatorPrey(model),
                                  nx=30, ny=30,
                                  seed = as.numeric(Sys.time())
                                  ) {
    pt0 <- summary(proc.time())
    res.times <- residence_times( trajectory, nx=nx, ny=ny )
    ## nx,ny index K not true max
    max.ix.nx <- max(res.times$ix, nx, na.rm=TRUE)
    max.iy.ny <- max(res.times$iy, ny, na.rm=TRUE)
    x <- (1:max.ix.nx)/nx
    y <- (1:max.iy.ny)/ny
    z <- get_matrix( res.times )
    xmax <- max(res.times$ix, na.rm=TRUE)/ny
    ymax <- max(res.times$iy, na.rm=TRUE)/ny
    pt1 <- summary(proc.time())
    pt <- pt1-pt0
    ##pt <- sum(ptdiff[c("user","system")])
    return( list(model=model, nx=nx, ny=ny, seed=seed, x=x, y=y, z=z,
                 xmax=xmax, ymax=ymax, proc.time=pt, type=attr(trajectory,"type"),
                 res.times=res.times,
                 origin=attr(res.times,"origin.entry.exit.times")
                 ) )
}
rtm_plot <- function( rtm, theta=0, phi=15, ... ) {
    require(plot3D)
    with( rtm, {
        hist3D(x, y, z,
               theta=theta,
               phi=phi,
               ylim=c(0,ymax),
               ticktype="detailed",
               ...)
        rStoch <- model$rStoch
        title(main=sprintf("%s%s ResTimes  (sigma = %g, K = %g, tf = %g, seed = %g)",
                           if (rStoch) {"r-"} else {""},
                           type,
                           if (rStoch) model$r.sigma else 0,
                           model$K, model$stopTime, seed))
        title(sub=sprintf("tilt = %g deg, azimuth=%g deg", phi, theta))
    })
}

get_cell_times <- function( traj, nx, ny ) {
    rtm.counts <- residence_times( traj, nx=nx, ny=ny )
    oc <- attr(rtm.counts, "origin.counts")
    K0c <- attr(rtm.counts, "K.0.counts")
    type <- attr(traj,"type")
    algorithm <- attr(traj,"model")$algorithm
    rStoch <- attr(traj,"model")$rStoch
    r.gamma <- attr(traj,"model")$r.gamma
    r.sigma <- attr(traj,"model")$r.sigma
    K <- attr(traj,"model")$K
    cell.times <- list(origin = oc$cell.time, carrying.capacity = K0c$cell.time,
                       type = type, rStoch = rStoch, r.gamma=r.gamma, r.sigma=r.sigma,
                       K = K)
    return(cell.times)
}
## base R histograms:
hist_cell_times <- function( ct, ... ) {
    ## backwards compatibility:
    if (is.null(ct$algorithm)) ct$algorithm <- ct$type
    if (ct$rStoch && (ct$algorithm != "ODE")) {
        full.type <- paste0("rStoch-", ct$algorithm, sprintf("(sigma=%g)",ct$r.sigma))
    } else {
        full.type <- ct$type
    }
    hist( ct$origin,
         main=sprintf("%s -- Origin", full.type),
         xlab="Time in cell containing (0,0)", ... )
    hist( ct$carrying.capacity,
         main=sprintf("%s -- Carrying Capacity", full.type),
         xlab=paste0("Time in cell containing (K=", ct$K, ",0)"), ... )
    message("hist_cell_times: ", full.type, "\n")
}

## FUNCTIONS FROM sirr PACKAGE:
##
#' Human-friendly time string
#' @param seconds a real number
#' @param sigdig number of significant digits to retain
#' @importFrom lubridate seconds_to_period
#' @export
time_string <- function(seconds,sigdig=4) {
  return(as.character(signif(lubridate::seconds_to_period(seconds),sigdig)))
}
##
#' Human-friendly CPU time string
#'
#' @param startTime CPU from which to count
#' @param sigdig number of significant digits to retain
#' @export
cpu_string <- function(startTime=0,sigdig=4) {
  totalTime <- proc.time() - startTime
  totalTimeSummary <- summary(totalTime)
  cpuSeconds <- totalTimeSummary["user"] + totalTimeSummary["system"]
  cpuTimeString <- time_string(cpuSeconds,sigdig)
  return(cpuTimeString)
}
