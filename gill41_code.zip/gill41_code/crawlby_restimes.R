
## read trajset.RData and compute residence times from the saved
## trajectories

source("crawlby_funs.R")

#####################
## RESIDENCE TIMES ##
#####################

load("trajset.RData")

library(doParallel)
registerDoParallel(cores=4)
restimeset <- foreach (i = 1:length(trajset)) %dopar% {
    traj <- trajset[[i]]$traj
    ######################
    ## FIX: for debugging:
    ##tail(traj)
    ##traj <- subset(traj, t <= 1000)
    ######################
    mm <- trajset[[i]]$model
    r.sigma <- mm$r.sigma
    h.sigma <- mm$h.sigma
    rtl <- residence_times(traj) # rtl = residence time list
    cat("Finished set ", i, "(r.sigma = ", r.sigma, ", h.sigma = ", h.sigma, ")\n")
    ## save results from this set in case others crash:
    restime  <- list(rtl = rtl, model = mm, r.sigma = r.sigma, h.sigma = h.sigma)
    fn <- sprintf("restimeset%d.RData", i)
    save(restime, file=fn)
    restime
}    

save(seed, algorithm,
     ## nx, ny,
     K, stopTime,
     r.sigma.vals, h.sigma.vals,
     restimeset,
     file="restimeset.RData")
