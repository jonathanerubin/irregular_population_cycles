
## combine trajsets that didn't crash

ivals <- 1:4

trajset <- list()
for (i in ivals) {
    fn <- sprintf("trajset%d.RData", i)
    load(fn)
    trajset[[i]] <- this.trajset
}

save(seed, algorithm,
     nx, ny, K, stopTime,
     r.sigma.vals, h.sigma.vals,
     trajset,
     file="trajset.RData")
