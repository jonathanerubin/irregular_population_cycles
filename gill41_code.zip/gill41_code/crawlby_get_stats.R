source("crawlby_funs.R")

#####################
## RESIDENCE TIMES ##
#####################

##load("trajset.RData")
load("restimeset.RData")

##############################################################
## for Jon: near-origin residence times calculated like him ##
##############################################################

region_times_stats <- function( x, region, sigma, algorithm ) {

    out <- c(region=region, sigma=sigma, ncycles=length(x),
             mean=mean(x), sd=sd(x), cycletime=stopTime/length(x))
    return(out)
}

## FIX: this is ridiculous technical debt... the whole thing ought to
##      be refactored to handle any number of regions...
origin.times <- list()
oeet <- list()
cc.times <- list()
cceet <- list()
yn.times <- list()
yneet <- list()
reg2.times <- list()
reg2eet <- list()
reg4.times <- list()
reg4eet <- list()
reg6.times <- list()
reg6eet <- list()
cycle.times <- list()
out <- data.frame()
for (i in 1:length(restimeset)) {
    origin.times[[i]] <- restimeset[[i]]$rtl$origin.times
    oeet[[i]] <- restimeset[[i]]$rtl$origin.entry.exit.times # for debugging
    cc.times[[i]] <- restimeset[[i]]$rtl$cc.times
    cceet[[i]] <- restimeset[[i]]$rtl$cc.entry.exit.times # for debugging
    yn.times[[i]] <- restimeset[[i]]$rtl$yn.times
    yneet[[i]] <- restimeset[[i]]$rtl$yn.entry.exit.times # for debugging 
    reg2.times[[i]] <- restimeset[[i]]$rtl$reg2.times
    reg2eet[[i]] <- restimeset[[i]]$rtl$reg2.entry.exit.times # for debugging
    reg4.times[[i]] <- restimeset[[i]]$rtl$reg4.times
    reg4eet[[i]] <- restimeset[[i]]$rtl$reg4.entry.exit.times # for debugging
    reg6.times[[i]] <- restimeset[[i]]$rtl$reg6.times
    reg6eet[[i]] <- restimeset[[i]]$rtl$reg6.entry.exit.times # for debugging
    cycle.times[[i]] <- restimeset[[i]]$rtl$cycle.times
    orts <- region_times_stats(origin.times[[i]], "ORIGIN",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    ccrts <- region_times_stats(cc.times[[i]], "CC",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    ynrts <- region_times_stats(yn.times[[i]], "yNULLCLINE",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    reg2rts <- region_times_stats(reg2.times[[i]], "region2",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    reg4rts <- region_times_stats(reg4.times[[i]], "region4",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    reg6rts <- region_times_stats(reg6.times[[i]], "region6",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    ## full cycle time series:
    fcts <- region_times_stats(cycle.times[[i]], "CYCLE",
                 restimeset[[i]]$model$h.sigma, restimeset[[i]]$model$algorithm)
    out <- rbind(out, orts, reg2rts, ccrts, reg4rts, ynrts, reg6rts, fcts)
}
names(out) <- c("region", "sigma", "ncycles", "mean", "sd", "cycletime")
for (i in 2:ncol(out)) out[,i] <- as.numeric(out[,i])
for (column in c("mean","sd")) out[,column] <- round(out[,column], 3)
out[,"cycletime"] <- round(out[,"cycletime"], 2)
library(dplyr)
out <- out %>% arrange(region)
write.csv(out, file="restimestats.csv", quote=FALSE, row.names=FALSE)
if (interactive()) View(out)
