
## simplified version of crawlby.R that just computes and saves
## trajectories so the residence time calculation can be separately
## run and debugged.

##Rprof()
##library(profvis)
##profvis({

source("crawlby_funs.R")

#####################
## RESIDENCE TIMES ##
#####################

##K <- 8000 # 10000
K <- 8000 # 10000
immigration.rate <- 1
algorithm <- "exact"
##algorithm <- "adaptive.tau"
startTime <- 1000 # ignore start of ODE run
##startTime <- 500 # ignore start of ODE run
stopTime <- 25000
##stopTime <- 2500
##stopTime <- 0.05 # for quick tests
message.interval <- 10^6
##
##nx <- 17
##ny <- 50
##nx <- 13
##ny <- 38
nx <- 10
ny <- 14
##nx <-  8
##ny <- 25
seed <- 16
## save r and h values generated for the first step.num.max events
##step.num.max <<- 10^6 # setting this so large will slow the code way too much
step.num.max <<- 1000
rvals.df <<- data.frame(t = rep(NA,step.num.max), r = rep(NA, step.num.max))
hvals.df <<- data.frame(t = rep(NA,step.num.max), h = rep(NA, step.num.max))

## For each parameter set, we need model, traj, rtm
h.sigma.vals <- c(0, 0.1, 0.2, 0.3)
r.sigma.vals <- rep(0, length(h.sigma.vals))

library(doParallel)
registerDoParallel(cores=4)
trajset <- foreach (i = 1:length(h.sigma.vals)) %dopar% {
####
####trajset <- list()
####for (i in 1:length(h.sigma.vals)) {
####
    h.sigma <- h.sigma.vals[i]
    r.sigma <- r.sigma.vals[i]
    mm <- create_PredatorPreyModel(
        K = K,
        immigration.rate = immigration.rate,
        startTime = startTime,
        stopTime = stopTime,
        algorithm = algorithm,
        hStoch = (h.sigma>0),
        h.sigma = h.sigma,
        rStoch = (r.sigma>0),
        r.sigma = r.sigma,
        message.interval = message.interval
    )
    traj <- ssa_PredatorPrey(model=mm, seed=seed)
    print(attr(traj,"proc.time"))
##    rtm <- residence_time_matrix(
##        model = mm,
##        trajectory = traj,
##        nx=nx, ny=ny, seed=seed)
##    print(rtm$proc.time)
    cat("Finished set ", i, "(r.sigma = ", r.sigma, ", h.sigma = ", h.sigma, ")\n")

    this.trajset <- list(iset = i, model = mm, traj = traj, r.sigma=r.sigma, h.sigma=h.sigma)
    ## save in case other sets crash
    save(this.trajset, seed, algorithm, r.sigma.vals, h.sigma.vals, nx, ny, K, stopTime,
         file=sprintf("trajset%d.RData", i))
    this.trajset  # will be accessible as trajset[[i]]    
}    

save(seed, algorithm,
     nx, ny, K, stopTime,
     r.sigma.vals, h.sigma.vals,
     trajset,
     file="trajset.RData")
##}) # end profvis
